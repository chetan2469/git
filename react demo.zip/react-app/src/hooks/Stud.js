import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    useRouteMatch,
    useParams,
  } from "react-router-dom";
  import React, { useEffect, useState } from 'react';
  
  export default function Stud() {
    
    const [roll, setRoll] = useState('')
    const [name, setName] = useState('')
    const [marks, setMarks] = useState('')
  
    
  
    const handleClick = (e) => {
      if(name.length==0 || roll.length==0 || marks.length==0 )
      {
        alert('Please fill all fields');
      }
      else{
        e.preventDefault()
      const user = { roll,name,marks }
      console.log(user)
      fetch("http://127.0.0.1:5000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
      }).then(() => {
        console.log('user Inserted')
        alert('admin Registration Successfully Done !!');
      })
      }
    }
  
  
   
  
  
  
    return (
      <>
        <br /><br /><br /><br />
        <section className="vh-100"  >
          <div className="container-fluid h-custom">
            <div className="row d-flex justify-content-center align-items-center h-100">
              <div className="col-lg-6">
                <img src='images/loginimage.png' width={'140%'}></img>
              </div>
              <div className="col-lg-6">
                <h1>Add new Admin</h1>
                <br /><br />
                <form>
                  <div className="divider d-flex align-items-center my-4" >
                  </div>
                  <div className="form-outline mb-4">
                    <input type="text" id="roll" value={roll} onChange={(e) => setRoll(e.target.value)} className="form-control form-control-lg" placeholder="Enter First Name " />
                    <br />
                  </div>
                  <div className="form-outline mb-3">
                    <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} className="form-control form-control-lg" placeholder="Enter Last Name " />
                    <br />
                  </div>
                  <div className="form-outline mb-4">
                    <input type="text" id="marks" value={marks} onChange={(e) => setMarks(e.target.value)} className="form-control form-control-lg" placeholder="Enter Mobile Number " />
                    <br />
                  </div>
                  <div className="d-flex justify-content-between align-items-center">
  
                  </div>
                  <div className="text-center text-lg-start mt-4 pt-2">
  
                    <button type="button" onClick={handleClick} className="btn btn-success btn-lg" style={{ paddingLeft: '2.5rem', paddingRight: '2.5rem' }}>Register</button>
                    </div>
                  <br />
                </form>
                <div >
  
                  
  
  
                </div>
              </div>
            </div>
          </div>
          <div></div>
        </section>
  
      </>
    )
  }
  