import React, { useState } from 'react'
import Name from './Name';

export default function AppHooks() {


  return <Name name={'name'} />;
}