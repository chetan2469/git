import React from 'react'

export default function Name({ name }) {
  return <div>My name is: {name}</div>;
}