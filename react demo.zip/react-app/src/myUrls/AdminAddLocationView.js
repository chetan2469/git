import React from 'react'
import AddLocation from '../myComponants/AddLocation'
import Banner from '../myComponants/Banner'
import Footer from '../myComponants/Footer'
import NavbarHeadeAdmin from '../myComponants/NavbarHeadeAdmin'

export default function AdminAddLocationView() {
  return (
    <>
    <NavbarHeadeAdmin/>
    <AddLocation/>
    <Footer/>

    </>
  )
}
