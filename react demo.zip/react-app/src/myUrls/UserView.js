import React from 'react'
import AllLocationsUser from '../myComponants/AllLocationsUser'
import Banner from '../myComponants/Banner'
import Footer from '../myComponants/Footer'
import GotoAdminSignin from '../myComponants/GotoAdminSignin'
import NavbarHeader from '../myComponants/NavbarHeader'
import Portfolio from '../myComponants/Portfolio'
import Region from '../myComponants/Region'

export default function UserView() {
  return (
      <>
            <NavbarHeader />
              <Banner />
              <Region />
              <Portfolio />
              <AllLocationsUser />
              <Footer />
      </>
  )
}
