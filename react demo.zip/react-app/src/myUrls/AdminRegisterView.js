import React from 'react'
import Banner from '../myComponants/Banner'
import Footer from '../myComponants/Footer'
import NavbarHeadeAdmin from '../myComponants/NavbarHeadeAdmin'
import Register from '../myComponants/Register'

export default function AdminRegisterView() {
  return (
      <>
      <NavbarHeadeAdmin/>
      <Register/>
      <Footer/>

      </>
  )
}
