
import AllLocations from '../myComponants/AllLocations'
import Banner from '../myComponants/Banner'
import Footer from '../myComponants/Footer'
import NavbarHeadeAdmin from '../myComponants/NavbarHeadeAdmin'

import React, { useEffect,useState } from 'react';
import UserProfile from '../sessionCookie/UserProfile';

export default function AdminDashboardView() {

  useEffect(() => {
    console.log('welcome to admn')
    console.log(UserProfile.getEmail())
  }, [])
  return (
    <>
    <NavbarHeadeAdmin/>
    <AllLocations/>
    <Footer/>
    </>
  )
}
