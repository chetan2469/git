import React from 'react'
import NavbarHeadeAdmin from '../myComponants/NavbarHeadeAdmin'
import AllEnquiries from '../myComponants/AllEnquiries'
import Banner from '../myComponants/Banner'
import Footer from '../myComponants/Footer'

export default function AdminEnquiriesView() {
  return (
      <>
      <NavbarHeadeAdmin/>
      <AllEnquiries/>
      <Footer/>
      
      </>
  )
}
