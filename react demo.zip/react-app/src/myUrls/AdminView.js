import React from 'react'
import Footer from '../myComponants/Footer'
import Signin from '../myComponants/Signin'

export default function AdminView() {
    return (
        <>

            <Signin />
            <Footer />
        </>
    )
}
