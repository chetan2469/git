import logo from './logo.svg';
import './App.css';
import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import UserView from './myUrls/UserView';
import AdminView from './myUrls/AdminView';
import AdminDashboardView from './myUrls/AdminDashboardView';
import AdminRegisterView from './myUrls/AdminRegisterView';
import AdminAddLocationView from './myUrls/AdminAddLocationView';
import AdminEnquiriesView from './myUrls/AdminEnquiriesView';
import PopupDemo from './hooks/PopupDemo';


// delete location
// add location issue


function App() {
  return (
    <>
      <Router>
        <div>

          <Switch>

            <Route exact path="/">
              <UserView />
            </Route>

            <Route exact path="/admin">
              <AdminView />
            </Route>

            <Route exact path="/adminDashboard">
              <AdminDashboardView />
            </Route>

            <Route exact path="/adminDashboardRegister">
              <AdminRegisterView />
            </Route>

            <Route exact path="/adminAddLocationView">
              <AdminAddLocationView />
            </Route>


            <Route exact path="/adminDashboardViewEnquiries">
              <AdminEnquiriesView />
            </Route>
          </Switch>




        </div>
      </Router>
    </>

  );
}

function Home() {
  return <h2>Home</h2>;
}


export default App;
