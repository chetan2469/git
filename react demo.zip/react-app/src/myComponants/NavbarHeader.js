import React from 'react'

export default function NavbarHeader() {
    return (
        <>
            <div>
  <div className="navbar navbar-fixed-top" data-activeslide={1}>
    <div className="container">
      {/* .navbar-toggle is used as the toggle for collapsed navbar content */}
      <button type="button" className="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
        <span className="icon-bar" />
        <span className="icon-bar" />
        <span className="icon-bar" />
      </button>
      <div className="nav-collapse collapse navbar-responsive-collapse">
        <ul className="nav row">
          <li data-slide={1} className="col-12 col-sm-2"><a id="menu-link-1" href="#slide-1" title="Next Section"><span className="icon icon-home" /> <span className="text">HOME</span></a></li>
          <li data-slide={2} className="col-12 col-sm-2"><a id="menu-link-2" href="#slide-2" title="Next Section"><span className="icon icon-facebook" /> <span className="text">ITINERARY</span></a></li>
          <li data-slide={3} className="col-12 col-sm-2"><a id="menu-link-3" href="#slide-3" title="Next Section"><span className="icon icon-briefcase" /> <span className="text">DESTINATION</span></a></li>
          <li data-slide={5} className="col-12 col-sm-2"><a id="menu-link-5" href="#slide-5" title="Next Section"><span className="icon icon-heart" /> <span className="text">Our Packages</span></a></li>
          <li data-slide={6} className="col-12 col-sm-2"><a id="menu-link-6" href="#slide-6" title="Next Section"><span className="icon icon-envelope" /> <span className="text">CONTACT US</span></a></li>
          
        </ul>
        <div className="row">
          <div className="col-sm-2 active-menu" />
        </div>
      </div>{/* /.nav-collapse */}
    </div>{/* /.container */}
  </div>{/* /.navbar */}
  {/* === Arrows === */}
  <div id="arrows">
    <div id="arrow-up" className="disabled" />
    <div id="arrow-down" />
    <div id="arrow-left" className="disabled visible-lg" />
    <div id="arrow-right" className="disabled visible-lg" />
  </div>{/* /.arrows */}
</div>

        </>




    )
}
