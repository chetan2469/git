import {
  Link
} from "react-router-dom";
import React, { useEffect,useState } from 'react';
import AddLocation from './AddLocation'
import AllLocations from './AllLocations'
import NavbarHeader from './NavbarHeader'
import UserProfile from "../sessionCookie/UserProfile";
import Register from "./Register";
import AllEnquiries from "./AllEnquiries";

export default function AdminDashboard() {


  return (
    <>
      <div class="container">
        <div class="jumbotron">
          <h2>Admin Dashboard {UserProfile.getEmail()}</h2>
          
          <Link to="/"><button type="button" class="btn btn-danger btn-lg">LogOut</button> </Link>
        </div>
      </div>
      <AllLocations/>
      <AddLocation />
      <Register/>
      <AllEnquiries/>
    </>
  )
}
