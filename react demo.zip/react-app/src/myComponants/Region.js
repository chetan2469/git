import React from 'react'

export default function Region() {
  return (
    <div className="slide story" id="slide-2" data-slide={2}>
    <div className="container">
        <div className="row title-row">
            <h2 className="col-12 font-thin">WE WANDER FOR, <span className="font-semibold">DISTRACTION</span> ,BUT WE TRAVEL FOR FULFILMENT</h2>
        </div>{/* /row */}
        <div className="row line-row">
            <div className="hr">&nbsp;</div>
        </div>{/* /row */}
        <div className="row subtitle-row">
            <h2 className="col-12 font-thin">TOURISM IS <span className="font-semibold">BEST WE CAN DO</span></h2>
        </div>{/* /row */}
        <div className="row content-row">
            <div className="col-12 col-lg-3 col-sm-6">
            <p><i className="icon icon-laptop" /></p>
                <h2 className="font-thin"><span className="font-semibold">BEACH SURFING</span></h2>
                <h4 className="font-thin">Sky above, sand below, peace within</h4>
            </div>{/* /col12 */}
            <div className="col-12 col-lg-3 col-sm-6">
                <p><i className="icon icon-laptop" /></p>
                <h2 className="font-thin"><span className="font-semibold">MOUNTAIN</span></h2>
                <h4 className="font-thin">The mountains are calling and I must go.</h4>
            </div>{/* /col12 */}
            <div className="col-12 col-lg-3 col-sm-6">
                <p><i className="icon icon-tablet" /></p>
                <h2 className="font-thin"><span className="font-semibold">JUNGLE SAFARI</span></h2>
                <h4 className="font-thin">A walk in nature walks the soul back home.</h4>
            </div>{/* /col12 */}
            <div className="col-12 col-lg-3 col-sm-6">
                <p><i className="icon icon-pencil" /></p>
                <h2 className="font-thin"><span className="font-semibold">FOOD</span></h2>
                <h4 className="font-thin">Good food is good mood.</h4>
            </div>{/* /col12 */}
        </div>{/* /row */}
    </div>{/* /container */}
</div>
  )
}
