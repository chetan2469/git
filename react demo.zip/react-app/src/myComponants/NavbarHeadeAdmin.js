import React from 'react'
import {
  Link
} from "react-router-dom";

export default function NavbarHeadeAdmin() {
  return (
    <>
      <div>
        <div className="navbar navbar-fixed-top" data-activeslide={1}>
          <div className="container">
            {/* .navbar-toggle is used as the toggle for collapsed navbar content */}
            <button type="button" className="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
              <span className="icon-bar" />
              <span className="icon-bar" />
              <span className="icon-bar" />
            </button>
            <div className="nav-collapse collapse navbar-responsive-collapse">
              <ul className="nav row">
              <Link to="/adminDashboard"><button type="button" class="btn btn-danger btn-sm">Admin Dashboard</button> </Link>
                <Link to="/adminDashboardRegister"><button type="button" class="btn btn-danger btn-sm">Add Admin</button> </Link>
                <Link to="/adminAddLocationView"><button type="button" class="btn btn-danger btn-sm">Add Location</button> </Link>
                <Link to="/adminDashboardViewEnquiries"><button type="button" class="btn btn-danger btn-sm">View Enquiries</button> </Link>
                <Link to="/"><button type="button" class="btn btn-danger btn-sm">Log Out</button> </Link>
              </ul>

              <div className="row">
                <div className="col-sm-2 active-menu" />
              </div>
            </div>{/* /.nav-collapse */}
          </div>{/* /.container */}
        </div>{/* /.navbar */}
        {/* === Arrows === */}
        <div id="arrows">
          <div id="arrow-up" className="disabled" />
          <div id="arrow-down" />
          <div id="arrow-left" className="disabled visible-lg" />
          <div id="arrow-right" className="disabled visible-lg" />
        </div>{/* /.arrows */}
      </div>

    </>




  )
}
