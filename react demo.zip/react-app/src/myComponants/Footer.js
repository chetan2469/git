import React from 'react'

export default function Footer() {
  return (
      <>

        {/* === Slide 6 / Contact === */}
        <div className="slide story" id="slide-6" data-slide={6}>
          <div className="container">
            <div className="row title-row">
              <div className="col-12 font-light">Leave us a <span className="font-semibold">message</span></div>
            </div>{/* /row */}
            <div className="row line-row">
              <div className="hr">&nbsp;</div>
            </div>{/* /row */}
            <div className="row subtitle-row">
              <div className="col-sm-1 hidden-sm">&nbsp;</div>
              <div className="col-12 col-sm-10 font-light">You can find us literally anywhere, just push a button and we’re there</div>
              <div className="col-sm-1 hidden-sm">&nbsp;</div>
            </div>{/* /row */}
            <div id="contact-row-4" className="row">
              <div className="col-sm-1 hidden-sm">&nbsp;</div>
              <div className="col-12 col-sm-2 with-hover-text">
                <p><a target="_blank" ><i className="icon icon-phone" /></a></p>
                <span className="hover-text font-light ">+9000900909</span>
              </div>{/* /col12 */}
              <div className="col-12 col-sm-2 with-hover-text">
                <p><a target="_blank" ><i className="icon icon-envelope" /></a></p>
                <span className="hover-text font-light ">indiatour@gmail.com</span>
              </div>{/* /col12 */}
              <div className="col-12 col-sm-2 with-hover-text">
                <p><a target="_blank" ><i className="icon icon-home" /></a></p>
                <span className="hover-text font-light ">Pune<br />zip code 98443</span>
              </div>{/* /col12 */}
              <div className="col-12 col-sm-2 with-hover-text">
                <p><a target="_blank" ><i className="icon icon-facebook" /></a></p>
                <span className="hover-text font-light ">facebook</span>
              </div>{/* /col12 */}
              <div className="col-12 col-sm-2 with-hover-text">
                <p><a target="_blank" ><i className="icon icon-twitter" /></a></p>
                <span className="hover-text font-light ">@IndiaTour</span>
              </div>{/* /col12 */}
              <div className="col-sm-1 hidden-sm">&nbsp;</div>
            </div>{/* /row */}
          </div>{/* /container */}
        </div>
      </>
  )
}
