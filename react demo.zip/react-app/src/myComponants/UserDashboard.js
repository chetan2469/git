import React from 'react'
import NavbarHeader from './NavbarHeader'
import {
  Link,
} from "react-router-dom";
import UserProfile from '../sessionCookie/UserProfile';

export default function UserDashboard() {
  return (
    <>

      <br /><br /><br /><br /><br /><br />
      <section className="vh-100"  >
        <div className="container h-custom">
          <div className="row d-flex justify-content-center align-items-center h-100">

            <div className="text-center text-lg-start mt-4 pt-2">

              <div>
                <h3>Admin Dashboard</h3>
              </div>
              &nbsp;&nbsp; <Link to="/userEnquiries"><button type="button" class="btn btn-danger btn-lg">visitors Enquiries</button> </Link>

              &nbsp;&nbsp; <Link to="/AddNewLocation"><button type="button" class="btn btn-danger btn-lg">Add New Location</button> </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
