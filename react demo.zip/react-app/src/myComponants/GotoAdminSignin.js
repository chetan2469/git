import React from 'react'
import {
    Link,
  } from "react-router-dom";

export default function GotoAdminSignin() {
    return (
        <>
            <ul class="nav justify-content-end">
            <li class="nav-item">
            <Link to="/admin"><button type="button" class="btn btn-warning btn-lg">Admin</button> </Link>
            </li>
        </ul>
    </>
  )
}
