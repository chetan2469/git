import React from 'react'

export default function EnquiryForm({name}) {
  return (
    <div>Hello {name}</div>
  )
}
