
import React, { useEffect,useState } from 'react';




export default function AllEnquiries() {

    const [enquiries, setAllEnquiries] = useState([])



  useEffect(() => {
    fetch("http://localhost:8080/enquiry/getAll")
      .then(res => res.json())
      .then((result) => {
        setAllEnquiries(result);
      }
      )
  }, [])

  return (
    <>

      <div class="container">
      <h2>Enquiries</h2>           
  <table class="table table-hover">
    <thead>
      <tr>
        <th>id</th>
        <th>name</th>
        <th>mobileNumber</th>
        <th>adultNumber</th>
        <th>childrenNumber</th>
        <th>choosenLocation</th>
      </tr>
    </thead>
    <tbody>
    {enquiries.map(loc=>(<tr>
      <td key={loc.id}>{loc.id}<br/></td>
      <td key={loc.id}>{loc.name}<br/></td>
      <td key={loc.id}>{loc.mobileNumber}<br/></td>
      <td key={loc.id}>{loc.adultNumber}<br/></td>
      <td key={loc.id}>{loc.childrenNumber}<br/></td>
      <td key={loc.id}>{loc.choosenLocation}<br/></td>
    </tr>))}
    
    </tbody>
  </table>
</div>

      
    </>
  )
}
