
import React, { useEffect, useState } from 'react';
import Popup from 'reactjs-popup';
import EnquiryPopup from './EnquiryPopup';
import EnquiryForm from './EnquiryPopup';




export default function AllLocationsUser() {

  const [name, setFullName] = useState('')
	const [mobileNumber, setMobileNumber] = useState('')
	const [adultNumber, setAdultNumbers] = useState('')
	const [childrenNumber, setChildrenNumber] = useState('')

  const [locations, setLocations] = useState([])
  const [users, setUsers] = useState([])

  let choosenLocation='blank';

  const enquirySubmit = (e) => {
    
		if(name.length==0 || mobileNumber.length==0 || adultNumber.length==0 || childrenNumber.length==0 )
		{
		  alert('Please fill all fields');
		}
		else{
		  e.preventDefault()
		const user = { name, mobileNumber, adultNumber, childrenNumber, choosenLocation}
		console.log(user)
		fetch("http://localhost:8080/enquiry/add", {
		  method: "POST",
		  headers: { "Content-Type": "application/json" },
		  body: JSON.stringify(user)
		}).then(() => {
		  console.log('user Inserted')
		  alert('we got your enquiry,  we will contact you');
      setFullName('')
      setMobileNumber('')
      setAdultNumbers('')
      setChildrenNumber('')
		})
		}
	  }


  //   useEffect(() => {
  //   fetch("localhost:8080/location/getAll")
  //     .then(res => res.json())
  //     .then((result) => {
  //       setLocations(result);
  //     }
  //     )
  // }, [])

  useEffect(() => {
    fetch("http://localhost:8080/location/getAll")
      .then(res => res.json())
      .then((result) => {
        setLocations(result);
      }
      )
  }, [])

  return (
    <>

      <div className="slide story" data-slide={5} >
        <div class="container">
          <h2>Our Packages</h2>
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Location</th>
                <th>Description</th>
                <th>Location Name</th>
                <th>Pickup Point</th>
                <th>Duration In Days</th>
                <th>Hotel Name</th>
                <th>Price per P</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {locations.map(loc => (<tr>
                <td key={loc.id}><img src={loc.locationUrl} width={'200px'}></img><br /></td>
                <td key={loc.id}>{loc.decription}<br /></td>
                <td key={loc.id}>{loc.locationName}<br /></td>
                <td key={loc.id}>{loc.pickupPoint}<br /></td>
                <td key={loc.id}>{loc.durationInDays}<br /></td>
                <td key={loc.id}>{loc.hotelName}<br /></td>
                <td key={loc.id}>{loc.price}<br /></td>
                <td key={loc.id}>
                <Popup trigger={<button> Show Interest </button>} position="left center">
			<h4>Add Enquiry {loc.locationName}</h4>
      {choosenLocation = loc.locationName}
					<br /><br />
					<form>
						<div >
						</div>
						<div className="form-outline">
							<input type="text" id="name" value={name} onChange={(e) => setFullName(e.target.value)} className="form-control form-control-lg" placeholder="Enter Name " />
							<br />
						</div>
						<div className="form-outline mb-4">
							<input type="text" id="mobileNumber" value={mobileNumber} onChange={(e) => setMobileNumber(e.target.value)} className="form-control form-control-lg" placeholder="Enter Mobile Number " />
							<br />
						</div>
						<div className="form-outline mb-4">
							<input type="text" id="adultNumber" value={adultNumber} onChange={(e) => setAdultNumbers(e.target.value)} className="form-control form-control-lg" placeholder="total adults " />
							<br />
						</div>
						<div className="form-outline mb-4">
							<input type="text" id="childrenNumber" value={childrenNumber} onChange={(e) => setChildrenNumber(e.target.value)} className="form-control form-control-lg" placeholder="total childs " />
							<br />
						</div>
						<div className="d-flex justify-content-between align-items-center">

						</div>
						<div className="text-center text-lg-start mt-4 pt-2">

							<button type="button" onClick={enquirySubmit} className="btn btn-success btn-lg" style={{ paddingLeft: '2.5rem', paddingRight: '2.5rem' }}>submit</button>
						</div>
						<br />
					</form>
			</Popup>
                  <br /></td>
                {/* <td key={loc.id}><button primary onClick={() => EnquiryForm(loc.locationName)}>Show Interest</button><br /></td>
                 */}
              </tr>))}

            </tbody>
          </table>
        </div>
      </div>{/* /slide3 */}




    </>
  )
}
