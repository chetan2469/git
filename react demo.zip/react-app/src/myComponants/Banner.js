import React from 'react'
import {
    Link,
  } from "react-router-dom";

export default function Banner() {
    return (
        <>


  
            <div>
                <div className="slide story" id="slide-1" data-slide={1}>
                    <div className="container">
                        <div id="home-row-1" className="row clearfix">
                            <div className="col-12">
                                <h1 className="font-semibold" color='black'>INCREDIBLE INDIA !</h1>
                                <br />
                                <br />
                                <Link to="/admin"><button type="button" class="btn btn-warning btn-lg">Signin as Admin</button> </Link>
                                {/* <Link to="/signin"><button type="button" class="btn btn-warning btn-lg">Signin</button> </Link>
                                &nbsp;
                                <Link to="/register"><button type="button" class="btn btn-danger btn-lg">Register</button> </Link> */}
                            </div>{/* /col-12 */}
                        </div>{/* /row */}
                        <div id="home-row-2" className="row clearfix">
                        </div>{/* /row */}
                    </div>{/* /container */}
                </div>{/* /slide1 */}
                {/* === Slide 2 === */}

            </div>
        </>
    )
}
