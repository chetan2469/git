
// import Popup from 'reactjs-popup';
// import React, { useEffect, useState } from 'react';
// import 'reactjs-popup/dist/index.css';

// export default function EnquiryPopup({loco}) {

	



// 	return (
// 		<div>
			
// 		</div>
// 	)
// };
