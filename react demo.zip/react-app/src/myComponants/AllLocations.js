
import React, { useEffect, useState } from 'react';




export default function AllLocations() {

  const [locations, setLocations] = useState([])
  const [users, setUsers] = useState([])


  //   useEffect(() => {
  //   fetch("localhost:8080/location/getAll")
  //     .then(res => res.json())
  //     .then((result) => {
  //       setLocations(result);
  //     }
  //     )
  // }, [])

  useEffect(() => {
    fetch("http://localhost:8080/location/getAll")
      .then(res => res.json())
      .then((result) => {
        setLocations(result);
      }
      )
  }, [])

  const deleteClick = id => (e) => {

    alert(id)
    e.preventDefault()
      const loc = { id }
      console.log(loc)
      fetch("http://localhost:8080/location/deleteLocation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loc)
      }).then(() => {

        alert('delete location  Successfully ');
        window.open('/adminDashboard',"_self");
      })

  }

  return (
    <>

      <div class="container">
        <h2>Our Locations</h2>
        <table class="table table-hover">
          <thead>
            <tr>
              <th>Location</th>
              <th>Description</th>
              <th>Location Name</th>
              <th>Pickup Point</th>
              <th>Duration In Days</th>
              <th>Hotel Name</th>
              {/* <th>actions</th> */}
            </tr>
          </thead>
          <tbody>
            {locations.map(loc => (<tr>
              <td key={loc.id}><img src={loc.locationUrl} width={'200px'}></img><br /></td>
              <td key={loc.id}>{loc.decription}<br /></td>
              <td key={loc.id}>{loc.locationName}<br /></td>
              <td key={loc.id}>{loc.pickupPoint}<br /></td>
              <td key={loc.id}>{loc.durationInDays}<br /></td>
              <td key={loc.id}>{loc.hotelName}<br /></td>
              <td><button type="button" onClick={deleteClick(loc.id)} className="btn btn-danger btn-sm" style={{ paddingLeft: '2.5rem', paddingRight: '2.5rem' }}>delete</button>
              </td>
            </tr>))}

          </tbody>
        </table>
      </div>


    </>
  )
}
