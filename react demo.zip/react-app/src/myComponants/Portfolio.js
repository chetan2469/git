import React from 'react'

export default function Portfolio() {
    return (
        <>
  <div className="slide story" id="slide-3" data-slide={3}>
  <div className="row">
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/North1.jpg"><img className="thumb" src="images/portfolio/Northsmall.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/North2.jpg"><img className="thumb" src="images/portfolio/North2small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/North3.jpg"><img className="thumb" src="images/portfolio/North3small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/North4.jpg"><img className="thumb" src="images/portfolio/North4small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/East1.jpg"><img className="thumb" src="images/portfolio/East1small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/East3.jpg"><img className="thumb" src="images/portfolio/East3small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/South1.jpg"><img className="thumb" src="images/portfolio/South1small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/South2.jpg"><img className="thumb" src="images/portfolio/South2small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/South3.jpg"><img className="thumb" src="images/portfolio/South3small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/South4.jpg"><img className="thumb" src="images/portfolio/South4small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/West1.jpg"><img className="thumb" src="images/portfolio/West1small.jpg" alt="" /></a></div>
    <div className="col-12 col-sm-6 col-lg-2"><a data-fancybox-group="portfolio" className="fancybox" href="images/portfolio/West2.jpg"><img className="thumb" src="images/portfolio/West2small.jpg" alt="" /></a></div>
  </div>{/* /row */}
</div>{/* /slide3 */}


        </>
    )
}
