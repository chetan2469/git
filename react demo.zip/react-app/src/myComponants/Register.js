import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useRouteMatch,
  useParams,
} from "react-router-dom";
import React, { useEffect, useState } from 'react';
import NavbarHeader from "./NavbarHeader";

export default function Register() {
  
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [mobileNumber, setMobileNumber] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [userType, setUserType] = useState('user')

  

  const handleClick = (e) => {
    if(firstName.length==0 || lastName.length==0 || email.length==0 || password.length==0 || mobileNumber.length==0)
    {
      alert('Please fill all fields');
    }
    else{
    e.preventDefault()
    const user = { firstName, lastName, email, password, mobileNumber,userType }
    // console.log(user)
    fetch("http://localhost:8080/user/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user)
    }).then(() => {
      console.log('user Inserted')
      alert('admin Registration Successfully Done !!');
    })
    }
  }


 



  return (
    <>
      <br /><br /><br /><br />
      <section className="vh-100"  >
        <div className="container-fluid h-custom">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-lg-6">
              <img src='images/loginimage.png' width={'140%'}></img>
            </div>
            <div className="col-lg-6">
              <h1>Add new Admin</h1>
              <br /><br />
              <form>
                <div className="divider d-flex align-items-center my-4" >
                </div>
                <div className="form-outline mb-4">
                  <input type="text" id="firstName" value={firstName} onChange={(e) => setFirstName(e.target.value)} className="form-control form-control-lg" placeholder="Enter First Name " />
                  <br />
                </div>
                <div className="form-outline mb-3">
                  <input type="text" id="lastName" value={lastName} onChange={(e) => setLastName(e.target.value)} className="form-control form-control-lg" placeholder="Enter Last Name " />
                  <br />
                </div>
                <div className="form-outline mb-4">
                  <input type="text" id="mobileNumber" value={mobileNumber} onChange={(e) => setMobileNumber(e.target.value)} className="form-control form-control-lg" placeholder="Enter Mobile Number " />
                  <br />
                </div>
                <div className="form-outline mb-3">
                  <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} className="form-control form-control-lg" placeholder="Enter email address" />
                  <br />
                </div>
                <div className="form-outline mb-4">
                  <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} className="form-control form-control-lg" placeholder="Enter password" />
                  <br />
                </div>
                <div className="d-flex justify-content-between align-items-center">

                </div>
                <div className="text-center text-lg-start mt-4 pt-2">

                  <button type="button" onClick={handleClick} className="btn btn-success btn-lg" style={{ paddingLeft: '2.5rem', paddingRight: '2.5rem' }}>Register</button>
                  </div>
                <br />
              </form>
              {/* {firstName}/{lastName}/{email}/{password}/{mobileNumber} */}
              <div >

                


              </div>
            </div>
          </div>
        </div>
        <div></div>
      </section>

    </>
  )
}
