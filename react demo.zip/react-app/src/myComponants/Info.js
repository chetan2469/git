import React from 'react'

export default function Info() {
  return (
  
    <>
    <div className="slide story" id="slide-5" data-slide={5}>
  <div className="container">
    <div className="row title-row">
    </div>{/* /row */}
    <div className="row line-row">
    </div>{/* /row */}
    <div className="row subtitle-row">
      <div className="col-sm-1 hidden-sm">&nbsp;</div>
      <div className="col-12 col-sm-10 font-light">One of the oldest civilisations in the world, India is a mosaic of multicultural experiences. With a rich heritage and myriad attractions, the country is among the most popular tourist destinations in the world. It covers an area of 32, 87,263 sq. km, extending from the snow-covered Himalayan heights to the tropical rain forests of the south. As the 7th largest country in the world, India stands apart from the rest of Asia, marked off as it is by mountains and the sea, which give the country a distinct geographical entity.</div>
      <div className="col-sm-1 hidden-sm">&nbsp;</div>
    </div>{/* /row */}
    <div className="row content-row">
      <div className="col-1 col-sm-1 hidden-sm">&nbsp;</div>
      <div className="col-1 col-sm-1 hidden-sm">&nbsp;</div>
    </div>{/* /row */}
  </div>{/* /container */}
</div>{/* /slide5 */}

    </>
  )
}
