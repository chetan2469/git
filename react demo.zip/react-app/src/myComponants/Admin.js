// import React from 'react'
// import AddLocation from './AddLocation'
// import NavbarHeader from './NavbarHeader'
// export default function Admin() {
//     return (
//         <>
//         <AddLocation />
//         <br/><br/><br/><br/><br/><br/>
        
//         </>
//     )
// }
