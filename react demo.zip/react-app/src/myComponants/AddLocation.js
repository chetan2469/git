import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useRouteMatch,
  useParams,
} from "react-router-dom";
import React, { useEffect, useState } from 'react';
import NavbarHeader from "./NavbarHeader";

export default function AddLocation() {
  const [locationName, setLocationName] = useState('')
  const [locationUrl, setLocationUrl] = useState('')
  const [pickupPoint, setPickupPoint] = useState('pune')
  const [durationInDays, setDurationInDays] = useState('')
  const [hotelName, setHotelName] = useState('')
  const [decription, setDecription] = useState('')
  const [price, setPrice] = useState('')




  const handleClick = (e) => {
    if (locationName.length == 0 || locationUrl.length == 0 || pickupPoint.length == 0 || durationInDays.length == 0 || hotelName.length == 0 || decription.length == 0 || price.length == 0) {
      alert('Please fill all fields');
    }
    else {
      e.preventDefault()
      const user = { locationName, locationUrl, pickupPoint, durationInDays, hotelName, decription, price }
      console.log(user)
      fetch("http://localhost:8080/location/addLocation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
      }).then(() => {
        console.log('new location Inserted')
        setLocationName('')
        setLocationUrl('')
        setPickupPoint('')
        setDurationInDays('')
        setPrice('')
        setHotelName('')
        setDecription('')

        alert('new location Inserted Successfully ');
        window.open('/adminDashboard',"_self");
      })
    }
  }






  return (
    <>
      <br /><br /><br /><br />
      <div className="slide story" id="slide-5" data-slide={5}>
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div className="col-lg-6">
            <img src={locationUrl} width={'40%'}></img>
          </div>
          <div >
            <h2>Add New Location Here...</h2>
            <br /><br />
            <form>
              <div className="divider d-flex align-items-center my-4" >
              </div>
              <div className="form-outline mb-4">
                <input type="text" id="locationName" value={locationName} onChange={(e) => setLocationName(e.target.value)} className="form-control form-control-lg" placeholder="Enter Location Name " />
                <br />
              </div>
              <div className="form-outline mb-3">
                <input type="text" id="locationUrl" value={locationUrl} onChange={(e) => setLocationUrl(e.target.value)} className="form-control form-control-lg" placeholder="Enter Location image address " />
                <br />
              </div>
              <div className="form-outline mb-4">
                <input type="text" id="pickupPoint" value={pickupPoint} onChange={(e) => setPickupPoint(e.target.value)} className="form-control form-control-lg" placeholder="pickup place example : pune " />
                <br />
              </div>
              <div className="form-outline mb-3">
                <input type="number" id="durationInDays" value={durationInDays} onChange={(e) => setDurationInDays(e.target.value)} className="form-control form-control-lg" placeholder="Duration in days" />
                <br />
              </div>
              <div className="form-outline mb-4">
                <input type="text" id="hotelName" value={hotelName} onChange={(e) => setHotelName(e.target.value)} className="form-control form-control-lg" placeholder="Hotel Name" />
                <br />
              </div>

              <div className="form-outline mb-4">
                <textarea type="textA" id="decription" value={decription} rows='5' onChange={(e) => setDecription(e.target.value)} className="form-control form-control-lg" placeholder="Package decription" />
                <br />
              </div>

              <div className="form-outline mb-4">
                <input type="textA" id="price" value={price} onChange={(e) => setPrice(e.target.value)} className="form-control form-control-lg" placeholder="Package Price in rupees" />
                <br />
              </div>
              <div className="d-flex justify-content-between align-items-center">

              </div>
              <div className="text-center text-lg-start mt-4 pt-2">

                <button type="button" onClick={handleClick} className="btn btn-success btn-lg" style={{ paddingLeft: '2.5rem', paddingRight: '2.5rem' }}>add location</button>
              </div>
              <br />
            </form>
            <div >




            </div>
          </div>
        </div>
      </div>{/* /slide5 */}

    </>
  )
}
