import 'package:cloud_firestore/cloud_firestore.dart';

class YVideo {
  final String title, duration, ids;

  YVideo(this.title, this.duration, this.ids);
}
