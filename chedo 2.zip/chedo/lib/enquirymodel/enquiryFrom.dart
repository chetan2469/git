// ignore_for_file: file_names

class EnquiryFromOption {
  String name, data, imageUrl;

  EnquiryFromOption(
      {required this.name, required this.imageUrl, required this.data});
}
